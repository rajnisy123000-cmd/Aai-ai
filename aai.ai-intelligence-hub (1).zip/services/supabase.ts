
/**
 * Local Storage based database engine.
 * Mimics the Supabase client interface to allow the app to run "without Google Cloud" or any backend.
 */

const getStorage = (key: string) => JSON.parse(localStorage.getItem(`aai_${key}`) || '[]');
const setStorage = (key: string, data: any) => localStorage.setItem(`aai_${key}`, JSON.stringify(data));

export const handleSupabaseError = (error: any) => {
  if (error) console.error('Storage Error:', error);
  return null;
};

export const supabase = {
  from: (table: string) => ({
    select: (query?: string) => ({
      order: (field: string, { ascending }: { ascending: boolean }) => {
        let data = getStorage(table);
        
        // Handle nested messages for sessions
        if (table === 'sessions') {
          const allMessages = getStorage('messages');
          data = data.map((session: any) => ({
            ...session,
            messages: allMessages.filter((m: any) => m.session_id === session.id)
          }));
        }

        data.sort((a: any, b: any) => ascending ? a[field] - b[field] : b[field] - a[field]);
        return Promise.resolve({ data, error: null });
      },
      eq: (field: string, value: any) => ({
        order: (oField: string, { ascending }: { ascending: boolean }) => {
          let data = getStorage(table).filter((item: any) => item[field] === value);
          data.sort((a: any, b: any) => ascending ? a[oField] - b[oField] : b[oField] - a[oField]);
          return Promise.resolve({ data, error: null });
        }
      })
    }),
    insert: (rows: any[]) => {
      const data = getStorage(table);
      setStorage(table, [...rows, ...data]);
      return Promise.resolve({ error: null });
    },
    delete: () => ({
      eq: (field: string, value: any) => {
        const data = getStorage(table).filter((item: any) => item[field] !== value);
        setStorage(table, data);
        return Promise.resolve({ error: null });
      }
    }),
    update: (updates: any) => ({
      eq: (field: string, value: any) => {
        const data = getStorage(table).map((item: any) => 
          item[field] === value ? { ...item, ...updates } : item
        );
        setStorage(table, data);
        return Promise.resolve({ error: null });
      }
    })
  }),
  isMock: false,
  isLocal: true
};
