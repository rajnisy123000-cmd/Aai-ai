
import { GoogleGenAI, Modality, GenerateContentResponse, Type } from "@google/genai";
import { Message, Source } from "../types";

// Helper to decode base64 to Uint8Array
function decodeBase64(base64: string): Uint8Array {
  const binaryString = atob(base64);
  const bytes = new Uint8Array(binaryString.length);
  for (let i = 0; i < binaryString.length; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

/**
 * Streams chat responses from Gemini-3-Flash-Preview.
 */
export async function* chatWithGeminiStream(prompt: string, history: Message[] = [], useSearch: boolean = false) {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const geminiHistory = history
    .filter(m => m.content.trim() !== '')
    .map(m => ({
      role: m.role === 'user' ? 'user' : 'model',
      parts: [{ text: m.content }]
    }));

  const chat = ai.chats.create({
    model: 'gemini-3-flash-preview',
    // @ts-ignore - history is supported in current SDK session creation
    history: geminiHistory as any,
    config: {
      systemInstruction: `You are Aai, a world-class AI assistant. ${useSearch ? 'Use Google Search for facts.' : ''}`,
      tools: useSearch ? [{ googleSearch: {} }] : undefined,
    }
  });

  try {
    const result = await chat.sendMessageStream({ message: prompt });
    let finalSources: Source[] = [];
    for await (const chunk of result) {
      const response = chunk as GenerateContentResponse;
      const metadata = response.candidates?.[0]?.groundingMetadata;
      if (metadata?.groundingChunks) {
        metadata.groundingChunks.forEach(c => {
          if (c.web) finalSources.push(c.web as Source);
        });
      }
      yield { text: response.text || '', sources: finalSources.length > 0 ? finalSources : undefined };
    }
  } catch (error) { throw error; }
}

/**
 * Generates videos using Veo 3.1 Fast with status polling.
 */
export async function generateVideo(prompt: string, onStatus: (status: string) => void) {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  onStatus("Initializing Render Engine...");
  
  let operation = await ai.models.generateVideos({
    model: 'veo-3.1-fast-generate-preview',
    prompt: prompt,
    config: {
      numberOfVideos: 1,
      resolution: '720p',
      aspectRatio: '16:9'
    }
  });

  const statuses = [
    "Drafting scene geometry...",
    "Simulating lighting and shadows...",
    "Synthesizing motion vectors...",
    "Upscaling texture details...",
    "Finalizing cinematic output..."
  ];
  let sIndex = 0;

  while (!operation.done) {
    onStatus(statuses[sIndex % statuses.length]);
    sIndex++;
    await new Promise(resolve => setTimeout(resolve, 10000));
    operation = await ai.operations.getVideosOperation({ operation: operation });
  }

  const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
  if (!downloadLink) throw new Error("Video generation failed to return a URI");
  
  const response = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
  const blob = await response.blob();
  return URL.createObjectURL(blob);
}

/**
 * Advanced App Builder using Gemini 3 Pro reasoning.
 */
export async function buildAppBlueprint(prompt: string) {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: prompt,
    config: {
      systemInstruction: "You are a senior full-stack architect. Provide a high-level technical blueprint, folder structure, and key code snippets for the user's requested application. Use Markdown formatting.",
    }
  });
  return response.text || "Failed to generate blueprint.";
}

// Fix: Updated generateImage to accept 4 arguments (prompt, aspectRatio, isPro, imageSize)
// to resolve the 'Expected 1-3 arguments, but got 4' error in ImagePage.tsx.
/**
 * Generates images using nano banana series models.
 */
export async function generateImage(prompt: string, aspectRatio: string = "1:1", isPro: boolean = false, imageSize: string = "1K") {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const model = isPro ? 'gemini-3-pro-image-preview' : 'gemini-2.5-flash-image';
  
  const response = await ai.models.generateContent({
    model: model,
    contents: { parts: [{ text: prompt }] },
    config: { 
      imageConfig: { 
        aspectRatio,
        // imageSize property is only valid for the Pro image model
        ...(isPro ? { imageSize } : {})
      } 
    }
  });

  // Iterate through parts to find the image data as per guidelines
  const part = response.candidates?.[0]?.content?.parts.find(p => p.inlineData);
  if (!part?.inlineData) throw new Error("Generation failed.");
  return `data:image/png;base64,${part.inlineData.data}`;
}

export async function textToSpeech(text: string, voiceName: string = 'Kore') {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash-preview-tts",
    contents: [{ parts: [{ text }] }],
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName } } },
    }
  });
  return response.candidates?.[0]?.content?.parts[0]?.inlineData?.data;
}

export async function decodeAudioData(base64: string, ctx: AudioContext) {
  const binaryString = atob(base64);
  const bytes = new Uint8Array(binaryString.length);
  for (let i = 0; i < binaryString.length; i++) bytes[i] = binaryString.charCodeAt(i);
  const dataInt16 = new Int16Array(bytes.buffer);
  // Audio bytes returned by API is raw PCM data, usually 24000Hz mono
  const buffer = ctx.createBuffer(1, dataInt16.length, 24000);
  const channelData = buffer.getChannelData(0);
  for (let i = 0; i < dataInt16.length; i++) channelData[i] = dataInt16[i] / 32768.0;
  return buffer;
}
