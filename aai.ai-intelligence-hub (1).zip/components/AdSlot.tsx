
import React, { useState, useEffect, useRef } from 'react';
import { Sparkles, X, AlertTriangle } from 'lucide-react';

interface AdSlotProps {
  id: string;
  format?: 'horizontal' | 'rectangle' | 'sidebar' | 'native';
  className?: string;
  adSlot?: string; // Specific Google AdSense Slot ID
  adClient?: string; // Specific Google AdSense Client ID
}

const AdSlot: React.FC<AdSlotProps> = ({ 
  id, 
  format = 'rectangle', 
  className = '', 
  adSlot = '1234567890', 
  adClient = 'ca-pub-1234567890123456' 
}) => {
  const [adState, setAdState] = useState<'loading' | 'filled' | 'error' | 'blocked'>('loading');
  const adRef = useRef<HTMLModElement>(null);

  useEffect(() => {
    const loadAd = () => {
      try {
        // Check if AdSense script is loaded and not blocked
        if (typeof window !== 'undefined' && (window as any).adsbygoogle) {
          ((window as any).adsbygoogle = (window as any).adsbygoogle || []).push({});
          setAdState('filled');
        } else {
          // If adsbygoogle doesn't exist after 2 seconds, assume blocked
          setTimeout(() => {
            if (!(window as any).adsbygoogle) {
              setAdState('blocked');
            }
          }, 2000);
        }
      } catch (e) {
        console.error("AdSense Error:", e);
        setAdState('error');
      }
    };

    const timer = setTimeout(loadAd, 500);
    return () => clearTimeout(timer);
  }, [id]);

  const dimensions = {
    horizontal: 'w-full h-24 md:h-32',
    rectangle: 'w-full aspect-[4/3] max-w-sm',
    sidebar: 'w-full h-64 md:h-96',
    native: 'w-full p-6',
  };

  const houseAds = [
    { title: "Unlock 4K Images", desc: "Aai Pro members generate ultra-high fidelity assets.", cta: "Upgrade Now" },
    { title: "Ad-Free Intelligence", desc: "Focus on your research without distractions.", cta: "Go Pro" },
    { title: "Priority Engine Access", desc: "Skip the queue for Gemini 3 Pro reasoning.", cta: "Get Priority" }
  ];
  
  const houseAd = houseAds[id.length % houseAds.length]; // Deterministic fallback

  return (
    <div className={`relative group ${className}`}>
      <div className="absolute -top-3 left-4 px-2 bg-slate-950 text-[10px] font-black text-slate-500 uppercase tracking-widest z-10 flex items-center gap-1">
        <Sparkles className="h-2 w-2 text-indigo-500" /> Sponsored
      </div>
      
      <div 
        id={`ad-wrapper-${id}`}
        className={`bg-slate-900/40 border border-white/5 rounded-[2rem] flex flex-col items-center justify-center overflow-hidden transition-all duration-500 hover:border-indigo-500/30 ${dimensions[format]} ${adState === 'loading' ? 'animate-pulse' : ''}`}
      >
        {/* Real Google AdSense Unit */}
        <ins 
          className="adsbygoogle"
          style={{ display: 'block', width: '100%', height: '100%' }}
          data-ad-client={adClient}
          data-ad-slot={adSlot}
          data-ad-format="auto"
          data-full-width-responsive="true"
          ref={adRef}
        />

        {/* Fallback UI (House Ads) displayed if AdSense fails or is blocked */}
        {(adState === 'blocked' || adState === 'error') && (
          <div className="absolute inset-0 w-full h-full flex flex-col items-center justify-center p-6 text-center bg-slate-900/90 backdrop-blur-sm animate-in fade-in duration-500">
             <div className="mb-4">
                <div className="flex items-center justify-center gap-2 mb-2">
                   <AlertTriangle className="h-3 w-3 text-amber-500/50" />
                   <p className="text-[9px] font-bold text-slate-500 uppercase tracking-tighter">Support Aai.ai</p>
                </div>
                <p className="text-sm font-black text-indigo-400 uppercase tracking-wider mb-1">{houseAd.title}</p>
                <p className="text-xs text-slate-400 max-w-[200px] leading-relaxed mx-auto">{houseAd.desc}</p>
             </div>
             <button className="px-6 py-2 bg-indigo-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-500/20 active:scale-95">
               {houseAd.cta}
             </button>
             
             <div className="absolute bottom-2 right-4 flex items-center gap-1 opacity-20 hover:opacity-100 transition-opacity">
               <span className="text-[8px] text-slate-500 font-bold uppercase">Privacy Info</span>
               <X className="h-2 w-2 cursor-pointer" />
             </div>
          </div>
        )}

        {adState === 'loading' && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 bg-slate-900/20 backdrop-blur-[2px]">
            <div className="w-8 h-8 border-2 border-slate-800 border-t-indigo-500 rounded-full animate-spin" />
            <span className="text-[10px] text-slate-600 font-bold uppercase tracking-widest">Aai Ads</span>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdSlot;
