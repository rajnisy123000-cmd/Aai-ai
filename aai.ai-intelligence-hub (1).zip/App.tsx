
import React from 'react';
import { HashRouter, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import LandingPage from './pages/LandingPage';
import ChatPage from './pages/ChatPage';
import ImagePage from './pages/ImagePage';
import VoicePage from './pages/VoicePage';
import PricingPage from './pages/PricingPage';
import VideoPage from './pages/VideoPage';
import AppBuilderPage from './pages/AppBuilderPage';

const App: React.FC = () => {
  return (
    <HashRouter>
      <div className="flex flex-col min-h-screen">
        <Navbar />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<LandingPage />} />
            <Route path="/chat" element={<ChatPage />} />
            <Route path="/image" element={<ImagePage />} />
            <Route path="/video" element={<VideoPage />} />
            <Route path="/forge" element={<AppBuilderPage />} />
            <Route path="/voice" element={<VoicePage />} />
            <Route path="/pricing" element={<PricingPage />} />
          </Routes>
        </main>
      </div>
    </HashRouter>
  );
};

export default App;
