
import React, { useState, useRef, useEffect, useMemo } from 'react';
import { Send, User, Bot, Loader2, Sparkles, AlertCircle, Plus, Trash2, MessageSquare, Globe, Save, Database } from 'lucide-react';
import { chatWithGeminiStream } from '../services/geminiService';
import { supabase } from '../services/supabase';
import { Message, ChatSession, Source } from '../types';
import AdSlot from '../components/AdSlot';

const ChatPage: React.FC = () => {
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [useSearch, setUseSearch] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isSyncing, setIsSyncing] = useState(false);
  
  const scrollRef = useRef<HTMLDivElement>(null);

  // Load from local storage engine on mount
  useEffect(() => {
    const fetchSessions = async () => {
      setIsSyncing(true);
      const { data, error } = await supabase
        .from('sessions')
        .select('*, messages(*)')
        .order('lastModified', { ascending: false });

      if (!error && data) {
        setSessions(data);
        if (data.length > 0) setCurrentSessionId(data[0].id);
      }
      setIsSyncing(false);
    };

    fetchSessions();
  }, []);

  const currentSession = useMemo(() => 
    sessions.find(s => s.id === currentSessionId) || null
  , [sessions, currentSessionId]);

  const messages = currentSession?.messages || [];

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTo({
        top: scrollRef.current.scrollHeight,
        behavior: 'smooth'
      });
    }
  }, [messages, isLoading]);

  const createNewSession = async () => {
    const newId = crypto.randomUUID();
    const newSession: ChatSession = {
      id: newId,
      title: 'New Conversation',
      messages: [],
      lastModified: Date.now()
    };

    setSessions(prev => [newSession, ...prev]);
    setCurrentSessionId(newId);
    setError(null);

    await supabase.from('sessions').insert([{ 
      id: newId, 
      title: newSession.title, 
      lastModified: newSession.lastModified 
    }]);
  };

  const deleteSession = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (window.confirm("Delete this conversation?")) {
      setSessions(prev => prev.filter(s => s.id !== id));
      if (currentSessionId === id) {
        setCurrentSessionId(null);
      }
      await supabase.from('sessions').delete().eq('id', id);
      await supabase.from('messages').delete().eq('session_id', id);
    }
  };

  const handleSendMessage = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!input.trim() || isLoading) return;

    let targetSessionId = currentSessionId;
    
    if (!targetSessionId) {
      targetSessionId = crypto.randomUUID();
      const newSession: ChatSession = {
        id: targetSessionId,
        title: input.substring(0, 30),
        messages: [],
        lastModified: Date.now()
      };
      setSessions(prev => [newSession, ...prev]);
      setCurrentSessionId(targetSessionId);
      await supabase.from('sessions').insert([{ id: targetSessionId, title: newSession.title, lastModified: Date.now() }]);
    }

    const userText = input;
    const userMsg: Message = {
      id: crypto.randomUUID(),
      role: 'user',
      content: userText,
      timestamp: Date.now(),
    };

    // Optimistic Update
    setSessions(prev => prev.map(s => s.id === targetSessionId ? {
      ...s,
      messages: [...s.messages, userMsg],
      lastModified: Date.now()
    } : s));

    // Persist User Message
    await supabase.from('messages').insert([{
      id: userMsg.id,
      session_id: targetSessionId,
      role: userMsg.role,
      content: userMsg.content,
      timestamp: userMsg.timestamp
    }]);

    setInput('');
    setIsLoading(true);

    const assistantId = crypto.randomUUID();
    const assistantMsg: Message = { id: assistantId, role: 'assistant', content: '', timestamp: Date.now() };
    
    setSessions(prev => prev.map(s => s.id === targetSessionId ? { ...s, messages: [...s.messages, assistantMsg] } : s));

    try {
      let fullContent = '';
      let accumulatedSources: Source[] = [];
      const sessionData = sessions.find(s => s.id === targetSessionId);
      const history = sessionData?.messages || [];
      
      const stream = chatWithGeminiStream(userText, history, useSearch);
      
      for await (const chunk of stream) {
        fullContent += chunk.text;
        if (chunk.sources) accumulatedSources = chunk.sources;

        setSessions(prev => prev.map(s => s.id === targetSessionId ? {
          ...s,
          messages: s.messages.map(m => m.id === assistantId ? { 
            ...m, 
            content: fullContent,
            sources: accumulatedSources.length > 0 ? accumulatedSources : undefined
          } : m)
        } : s));
      }

      // Final persistence
      await supabase.from('messages').insert([{
        id: assistantId,
        session_id: targetSessionId,
        role: 'assistant',
        content: fullContent,
        sources: accumulatedSources,
        timestamp: Date.now()
      }]);

    } catch (err) {
      console.error(err);
      setError("Model connection failed. Check your internet or API key.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex h-screen bg-slate-950 pt-16">
      <div className="hidden lg:flex w-80 flex-col border-r border-white/5 bg-slate-950/50 backdrop-blur-xl">
        <div className="p-4 space-y-4">
          <button 
            onClick={createNewSession}
            className="flex items-center justify-center gap-2 w-full p-4 rounded-2xl bg-indigo-600 text-white hover:bg-indigo-700 transition-all font-bold shadow-lg"
          >
            <Plus className="h-5 w-5" /> New Chat
          </button>
        </div>
        
        <div className="flex-1 overflow-y-auto px-2 custom-scrollbar">
          <div className="flex items-center justify-between px-4 mb-3 mt-4">
            <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest flex items-center gap-2">
              <Database className="h-3 w-3" /> Local Library
            </p>
            {isSyncing && <Loader2 className="h-3 w-3 text-indigo-400 animate-spin" />}
          </div>

          {sessions.length === 0 && !isSyncing && (
            <div className="px-4 py-8 text-center opacity-40">
              <MessageSquare className="h-8 w-8 mx-auto mb-2" />
              <p className="text-xs">No conversations yet</p>
            </div>
          )}

          {sessions.map((session) => (
            <div 
              key={session.id}
              onClick={() => setCurrentSessionId(session.id)}
              className={`group relative flex items-center gap-3 p-3 rounded-xl transition-all cursor-pointer border ${
                currentSessionId === session.id 
                  ? 'bg-indigo-500/10 border-indigo-500/30 text-indigo-300' 
                  : 'bg-transparent border-transparent text-slate-400 hover:bg-white/5'
              }`}
            >
              <MessageSquare className="h-4 w-4 shrink-0" />
              <p className="text-sm font-medium truncate flex-1">{session.title}</p>
              <button onClick={(e) => deleteSession(session.id, e)} className="opacity-0 group-hover:opacity-100 p-1 hover:text-red-400 transition-opacity">
                <Trash2 className="h-3.5 w-3.5" />
              </button>
            </div>
          ))}
        </div>
      </div>

      <div className="flex-1 flex flex-col relative bg-slate-950">
        <div ref={scrollRef} className="flex-1 overflow-y-auto px-4 md:px-8 space-y-12 pb-32 pt-8">
          {(!currentSession || messages.length === 0) && (
            <div className="max-w-3xl mx-auto py-20 text-center">
              <div className="w-24 h-24 bg-indigo-500/10 rounded-[2.5rem] flex items-center justify-center mx-auto mb-10 border border-indigo-500/20 shadow-2xl animate-pulse">
                <Sparkles className="h-12 w-12 text-indigo-500" />
              </div>
              <h2 className="text-4xl md:text-5xl font-black mb-6 tracking-tight text-white">
                Intelligence Hub
              </h2>
              <p className="text-slate-400 text-lg mb-12">
                Your research is stored privately on this device.
              </p>
              <button onClick={() => setInput("What are the most promising AI breakthroughs in 2025?")} className="px-8 py-4 bg-slate-900 rounded-2xl border border-white/5 hover:border-indigo-500/50 transition-all font-bold">
                Try: "AI breakthroughs in 2025"
              </button>
            </div>
          )}

          {messages.map((m) => (
            <div key={m.id} className={`flex gap-4 ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`flex flex-col gap-3 max-w-[85%] ${m.role === 'user' ? 'items-end' : 'items-start'}`}>
                {m.sources && (
                  <div className="flex flex-wrap gap-2 mb-2">
                    {m.sources.map((s, i) => (
                      <a key={i} href={s.uri} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 px-2 py-1 rounded-md bg-slate-900 border border-white/5 text-[10px] text-slate-400 hover:text-indigo-400">
                        <Globe className="h-3 w-3" /> {s.title}
                      </a>
                    ))}
                  </div>
                )}
                <div className={`px-6 py-4 rounded-[2rem] shadow-xl ${m.role === 'user' ? 'bg-indigo-600 text-white rounded-tr-none' : 'bg-slate-900 border border-white/10 text-slate-200 rounded-tl-none'}`}>
                  <p className="whitespace-pre-wrap leading-relaxed">{m.content || <span className="animate-pulse">Thinking...</span>}</p>
                </div>
              </div>
            </div>
          ))}
          {error && (
            <div className="max-w-md mx-auto p-4 bg-red-500/10 border border-red-500/20 rounded-2xl text-red-400 text-sm flex items-center gap-3">
              <AlertCircle className="h-5 w-5 shrink-0" />
              {error}
            </div>
          )}
        </div>

        <div className="absolute bottom-0 left-0 w-full p-4 md:p-8 bg-gradient-to-t from-slate-950 via-slate-950/95 to-transparent">
          <form onSubmit={handleSendMessage} className="max-w-4xl mx-auto relative">
            <div className="flex items-center gap-2 mb-3">
              <button type="button" onClick={() => setUseSearch(!useSearch)} className={`px-4 py-1.5 rounded-full border text-[10px] font-bold transition-all flex items-center gap-2 ${useSearch ? 'bg-indigo-600 border-indigo-400 text-white' : 'bg-slate-900 border-white/5 text-slate-500'}`}>
                <Globe className={`h-3 w-3 ${useSearch ? 'animate-pulse' : ''}`} /> Web Search {useSearch ? 'ON' : 'OFF'}
              </button>
            </div>
            <div className="relative group">
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSendMessage();
                  }
                }}
                placeholder="Message Aai..."
                rows={1}
                className="w-full bg-slate-900/90 backdrop-blur-2xl border border-white/10 rounded-3xl pl-8 pr-20 py-5 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 text-white resize-none"
              />
              <button type="submit" disabled={isLoading || !input.trim()} className="absolute right-3 top-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-indigo-600 flex items-center justify-center glow-primary hover:bg-indigo-700 disabled:opacity-20 transition-all">
                {isLoading ? <Loader2 className="h-5 w-5 text-white animate-spin" /> : <Send className="h-5 w-5 text-white" />}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default ChatPage;
