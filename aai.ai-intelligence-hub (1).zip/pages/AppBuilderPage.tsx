
import React, { useState } from 'react';
import { Cpu, Sparkles, Loader2, Code, Terminal, Rocket, Layout, Box, Share2 } from 'lucide-react';
import { buildAppBlueprint } from '../services/geminiService';

const AppBuilderPage: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [blueprint, setBlueprint] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleForge = async () => {
    if (!prompt.trim() || isLoading) return;
    setIsLoading(true);
    try {
      const result = await buildAppBlueprint(prompt);
      setBlueprint(result);
    } catch (error) {
      alert("Forge error: Could not ignite the engine.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen pt-24 bg-slate-950 px-4 pb-20">
      <div className="max-w-7xl mx-auto h-full">
        <div className="flex flex-col lg:flex-row gap-12 h-full">
          <div className="w-full lg:w-[400px] space-y-8">
            <div className="space-y-2">
              <h1 className="text-4xl font-black text-white flex items-center gap-3">
                <Cpu className="text-indigo-500 h-10 w-10" /> FORGE
              </h1>
              <p className="text-slate-500 text-sm font-medium tracking-tight">AI Systems Architect powered by Gemini 3 Pro</p>
            </div>

            <div className="bg-slate-900/40 p-8 rounded-[2.5rem] border border-white/5 space-y-6">
              <div className="space-y-3">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Application Concept</label>
                <textarea
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  placeholder="Build a real-time analytics dashboard for a SaaS platform with React and Supabase..."
                  className="w-full h-64 bg-slate-950 border border-white/10 rounded-2xl p-5 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50 resize-none transition-all font-mono"
                />
              </div>

              <button
                onClick={handleForge}
                disabled={isLoading || !prompt.trim()}
                className="w-full py-6 rounded-2xl bg-indigo-600 text-white font-black text-xl glow-primary hover:bg-indigo-700 flex items-center justify-center gap-4 transition-all disabled:opacity-50"
              >
                {isLoading ? <Loader2 className="animate-spin h-6 w-6" /> : <Rocket className="h-6 w-6" />}
                {isLoading ? 'Forging...' : 'Ignite Engine'}
              </button>
            </div>

            <div className="grid grid-cols-2 gap-4">
              {[
                { icon: Box, label: 'Microservices' },
                { icon: Layout, label: 'UI Patterns' }
              ].map((t, i) => (
                <div key={i} className="p-4 bg-slate-900/40 border border-white/5 rounded-2xl flex items-center gap-3">
                  <t.icon className="h-4 w-4 text-indigo-400" />
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-tighter">{t.label}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="flex-1 flex flex-col bg-slate-900/20 rounded-[3rem] border border-white/5 overflow-hidden min-h-[600px]">
            <div className="flex items-center justify-between p-6 border-b border-white/5 bg-slate-900/40">
              <div className="flex items-center gap-3">
                <Terminal className="h-5 w-5 text-indigo-500" />
                <h2 className="text-sm font-black text-white uppercase tracking-widest">Architecture Blueprint</h2>
              </div>
              <button className="p-2 hover:bg-white/5 rounded-lg text-slate-500 hover:text-white transition-all">
                <Share2 className="h-4 w-4" />
              </button>
            </div>

            <div className="flex-1 p-8 overflow-y-auto custom-scrollbar font-mono text-sm leading-relaxed text-slate-300">
              {isLoading ? (
                <div className="space-y-4 animate-pulse">
                  <div className="h-4 bg-slate-800 rounded w-3/4" />
                  <div className="h-4 bg-slate-800 rounded w-1/2" />
                  <div className="h-4 bg-slate-800 rounded w-5/6" />
                  <div className="h-32 bg-slate-800 rounded w-full" />
                </div>
              ) : blueprint ? (
                <div className="prose prose-invert max-w-none whitespace-pre-wrap">
                  {blueprint}
                </div>
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-center space-y-6 opacity-30">
                   <div className="w-24 h-24 rounded-full border border-dashed border-indigo-500/50 flex items-center justify-center">
                     <Code className="h-10 w-10 text-indigo-500" />
                   </div>
                   <p className="text-sm font-bold uppercase tracking-widest">Waiting for Blueprint prompt...</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AppBuilderPage;
