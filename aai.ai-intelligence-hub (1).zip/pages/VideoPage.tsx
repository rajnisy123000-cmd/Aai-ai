
import React, { useState, useEffect } from 'react';
import { Video, Sparkles, Loader2, Download, Play, Clapperboard, Layers, History, ShieldAlert } from 'lucide-react';
import { generateVideo } from '../services/geminiService';
import { supabase } from '../services/supabase';

const VideoPage: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [status, setStatus] = useState('');
  const [videos, setVideos] = useState<any[]>([]);

  useEffect(() => {
    const fetchVideos = async () => {
      const { data } = await supabase.from('generated_videos').select('*').order('timestamp', { ascending: false });
      if (data) setVideos(data);
    };
    fetchVideos();
  }, []);

  const handleGenerate = async () => {
    if (!prompt.trim() || isLoading) return;

    if (typeof window !== 'undefined' && (window as any).aistudio) {
      const hasKey = await (window as any).aistudio.hasSelectedApiKey();
      if (!hasKey) {
        await (window as any).aistudio.openSelectKey();
      }
    }

    setIsLoading(true);
    setStatus("Waking up Veo...");
    try {
      const videoUrl = await generateVideo(prompt, setStatus);
      const newVideo = {
        id: crypto.randomUUID(),
        url: videoUrl,
        prompt: prompt,
        timestamp: Date.now()
      };
      setVideos(prev => [newVideo, ...prev]);
      await supabase.from('generated_videos').insert([newVideo]);
    } catch (error: any) {
      alert(`Production halted: ${error.message}`);
    } finally {
      setIsLoading(false);
      setStatus('');
    }
  };

  return (
    <div className="min-h-screen pt-24 bg-slate-950 px-4 pb-20">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col lg:flex-row gap-12">
          <div className="w-full lg:w-[450px] space-y-8">
            <div className="space-y-2">
              <h1 className="text-4xl font-black text-white flex items-center gap-3 italic">
                <Clapperboard className="text-indigo-500 h-10 w-10" /> MOTION
              </h1>
              <p className="text-slate-500 text-sm font-medium tracking-tight">Cinematic AI Video Production powered by Veo 3.1</p>
            </div>

            <div className="space-y-6 bg-slate-900/40 p-8 rounded-[2.5rem] border border-white/5 backdrop-blur-xl">
              <div className="space-y-3">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Director's Script</label>
                <textarea
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  placeholder="A cinematic drone shot of a futuristic cyberpunk city at dawn, neon lights reflecting on wet streets..."
                  className="w-full h-48 bg-slate-950 border border-white/10 rounded-2xl p-5 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50 resize-none transition-all placeholder:text-slate-700 font-medium"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-slate-950/50 border border-white/5 rounded-2xl">
                  <p className="text-[8px] font-bold text-slate-600 uppercase mb-1">Resolution</p>
                  <p className="text-white font-bold text-sm">720p HD</p>
                </div>
                <div className="p-4 bg-slate-950/50 border border-white/5 rounded-2xl">
                  <p className="text-[8px] font-bold text-slate-600 uppercase mb-1">Aspect Ratio</p>
                  <p className="text-white font-bold text-sm">16:9 Wide</p>
                </div>
              </div>

              <button
                onClick={handleGenerate}
                disabled={isLoading || !prompt.trim()}
                className="w-full py-6 rounded-2xl bg-indigo-600 text-white font-black text-xl glow-primary hover:bg-indigo-700 flex items-center justify-center gap-4 transition-all disabled:opacity-50 active:scale-95 group"
              >
                {isLoading ? <Loader2 className="animate-spin h-6 w-6" /> : <Play className="h-6 w-6 group-hover:scale-110 transition-transform" />}
                {isLoading ? 'Processing...' : 'Action'}
              </button>

              <div className="flex gap-3 p-4 bg-amber-500/5 border border-amber-500/20 rounded-xl">
                <ShieldAlert className="h-5 w-5 text-amber-500 shrink-0" />
                <p className="text-[10px] text-amber-200/60 leading-tight">
                  Video generation takes 2-5 minutes. Please do not refresh the page during production.
                </p>
              </div>
            </div>
          </div>

          <div className="flex-1 space-y-8">
            {isLoading && (
              <div className="aspect-video w-full bg-slate-900 rounded-[3rem] border border-white/5 flex flex-col items-center justify-center gap-6 relative overflow-hidden">
                <div className="absolute inset-0 bg-indigo-600/5 animate-pulse" />
                <div className="w-20 h-20 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin shadow-[0_0_40px_rgba(99,102,241,0.4)]" />
                <div className="text-center space-y-2">
                  <p className="text-xl font-black text-white italic tracking-tighter uppercase">{status}</p>
                  <p className="text-slate-500 text-xs font-bold uppercase tracking-widest">Encoding Master Frame</p>
                </div>
              </div>
            )}

            <div className="flex items-center justify-between border-b border-white/5 pb-4">
              <h2 className="text-xl font-black flex items-center gap-3 text-slate-300">
                <History className="h-5 w-5 text-indigo-500" />
                PRODUCTION REELS
              </h2>
            </div>

            {videos.length === 0 && !isLoading && (
              <div className="h-[400px] border-2 border-dashed border-white/5 rounded-[3rem] flex flex-col items-center justify-center text-slate-600">
                <Video className="h-12 w-12 opacity-20 mb-4" />
                <p className="font-bold">The reel is empty</p>
              </div>
            )}

            <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
              {videos.map((vid) => (
                <div key={vid.id} className="group bg-slate-900 rounded-[2.5rem] overflow-hidden border border-white/5 hover:border-indigo-500/30 transition-all shadow-2xl">
                  <video src={vid.url} controls className="w-full aspect-video object-cover" />
                  <div className="p-6 space-y-4">
                    <p className="text-sm text-slate-400 font-medium line-clamp-2 italic">"{vid.prompt}"</p>
                    <a href={vid.url} download className="flex items-center justify-center gap-2 w-full py-3 bg-white/5 hover:bg-white/10 rounded-xl text-[10px] font-black uppercase tracking-widest text-white transition-all">
                      <Download className="h-4 w-4" /> Export Asset
                    </a>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VideoPage;
