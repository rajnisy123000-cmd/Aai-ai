
import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Sparkles, 
  MessageSquare, 
  Image as ImageIcon, 
  Mic, 
  Zap,
  ArrowRight,
  ShieldCheck,
  Globe,
  Video,
  Cpu
} from 'lucide-react';

const features = [
  {
    icon: MessageSquare,
    title: 'Multi-Model Chat',
    description: 'Access state-of-the-art reasoning models like Gemini 3 Pro from one interface.',
    path: '/chat',
    color: 'text-blue-500'
  },
  {
    icon: ImageIcon,
    title: 'Image Studio',
    description: 'Generate stunning AI images with 2K/4K resolution support and custom styles.',
    path: '/image',
    color: 'text-purple-500'
  },
  {
    icon: Video,
    title: 'Motion Production',
    description: 'Cinematic text-to-video synthesis powered by the revolutionary Veo engine.',
    path: '/video',
    color: 'text-rose-500'
  },
  {
    icon: Cpu,
    title: 'The Forge',
    description: 'Build complex applications and architectures with AI system logic.',
    path: '/forge',
    color: 'text-emerald-500'
  },
];

const LandingPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-slate-950 pt-16 selection:bg-indigo-500/30">
      <section className="relative pt-24 pb-20 px-4 overflow-hidden text-center">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-20 left-1/4 w-[500px] h-[500px] bg-indigo-600/10 rounded-full blur-[120px] animate-pulse-glow" />
        </div>
        <div className="max-w-7xl mx-auto relative z-10">
          <div className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-indigo-500/10 text-indigo-400 text-xs font-bold uppercase tracking-widest mb-10 border border-indigo-500/20 shadow-2xl">
            <Sparkles className="h-3.5 w-3.5" />
            Superhub v3.0: Video & Code Modules Active
          </div>
          <h1 className="text-6xl md:text-8xl lg:text-9xl font-black mb-10 leading-[0.95] tracking-tighter text-white">
            Future of <br />
            <span className="gradient-text">Intelligence.</span>
          </h1>
          <p className="text-xl md:text-2xl text-slate-400 max-w-2xl mx-auto mb-14 font-medium leading-relaxed">
            Aai.ai is the world's most versatile AI cockpit. Chat, create, code, and produce with the most powerful neural networks on Earth.
          </p>
          <div className="flex flex-col sm:flex-row gap-6 justify-center mb-24">
            <Link to="/chat" className="flex items-center justify-center gap-2 px-12 py-6 rounded-2xl bg-indigo-600 text-white font-black text-xl glow-primary hover:bg-indigo-700 hover:scale-[1.02] transition-all group active:scale-95">
              Enter Hub
              <ArrowRight className="h-6 w-6 group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>
        </div>
      </section>

      <section className="py-20 px-4 bg-slate-900/30">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature) => (
              <Link key={feature.title} to={feature.path} className="group p-10 rounded-[2.5rem] bg-slate-900/50 border border-white/5 hover:border-indigo-500/50 hover-lift block backdrop-blur-sm">
                <div className="w-16 h-16 rounded-2xl bg-white/5 flex items-center justify-center mb-8 group-hover:bg-indigo-500/10 transition-colors">
                  <feature.icon className={`h-8 w-8 ${feature.color}`} />
                </div>
                <h3 className="text-2xl font-bold mb-4 text-white">{feature.title}</h3>
                <p className="text-slate-400 leading-relaxed mb-6 font-medium">{feature.description}</p>
                <div className="flex items-center gap-2 text-indigo-400 font-bold text-sm">
                  Launch Module <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <footer className="border-t border-white/5 py-24 px-4 bg-slate-950">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-8 text-slate-600 text-xs font-bold uppercase tracking-widest">
            <p>© {new Date().getFullYear()} Aai.ai Intelligence Systems Corp.</p>
            <div className="flex gap-8">
              <div className="flex items-center gap-2"><Globe className="h-3 w-3" /> Global Network</div>
              <div className="flex items-center gap-2"><ShieldCheck className="h-3 w-3" /> ISO Certified</div>
            </div>
        </div>
      </footer>
    </div>
  );
}

export default LandingPage;
