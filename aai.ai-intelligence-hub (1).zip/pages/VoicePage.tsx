
import React, { useState, useRef } from 'react';
import { Mic, Volume2, Play, Loader2, Download, Headphones, Music, Sparkles, Zap } from 'lucide-react';
import { textToSpeech, decodeAudioData } from '../services/geminiService';
import AdSlot from '../components/AdSlot';

const voices = [
  { id: 'Kore', name: 'Kore', gender: 'Female', style: 'Cheerful' },
  { id: 'Puck', name: 'Puck', gender: 'Male', style: 'Steady' },
  { id: 'Charon', name: 'Charon', gender: 'Male', style: 'Authoritative' },
  { id: 'Fenrir', name: 'Fenrir', gender: 'Male', style: 'Warm' },
  { id: 'Zephyr', name: 'Zephyr', gender: 'Neutral', style: 'Clear' },
];

const VoicePage: React.FC = () => {
  const [text, setText] = useState('');
  const [selectedVoice, setSelectedVoice] = useState('Kore');
  const [isLoading, setIsLoading] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  
  const audioContextRef = useRef<AudioContext | null>(null);

  const handleSynthesize = async () => {
    if (!text.trim() || isLoading) return;

    setIsLoading(true);
    setAudioUrl(null);
    try {
      const base64Audio = await textToSpeech(text, selectedVoice);
      
      if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      }
      
      const buffer = await decodeAudioData(base64Audio, audioContextRef.current);
      
      setIsPlaying(true);
      const source = audioContextRef.current.createBufferSource();
      source.buffer = buffer;
      source.connect(audioContextRef.current.destination);
      source.onended = () => setIsPlaying(false);
      source.start();

      // Convert to a playable WAV-like blob for downloading
      const blob = new Blob([new Uint8Array(atob(base64Audio).split("").map(c => c.charCodeAt(0)))], { type: 'audio/pcm' });
      const url = URL.createObjectURL(blob);
      setAudioUrl(url);
      
    } catch (error) {
      console.error(error);
      alert('Failed to synthesize speech. Check your API key and network.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen pt-24 bg-slate-950 px-4 pb-20">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16 relative">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-40 h-40 bg-indigo-500/10 blur-[80px] -z-10 rounded-full" />
          <h1 className="text-4xl md:text-6xl font-black mb-6 flex items-center justify-center gap-4">
            <Headphones className="text-indigo-500 h-10 w-10 md:h-14 md:w-14" />
            Voice Lab
          </h1>
          <p className="text-slate-400 text-xl max-w-2xl mx-auto font-medium">
            Experience ultra-realistic neural speech synthesis powered by Gemini 2.5.
          </p>
        </div>

        <div className="grid lg:grid-cols-12 gap-8 items-start">
          <div className="lg:col-span-8 bg-slate-900/40 border border-white/10 rounded-[3rem] p-8 md:p-12 backdrop-blur-xl shadow-2xl">
            <div className="space-y-8">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Script Input</label>
                  <span className="text-[10px] text-slate-600 font-bold">{text.length} / 5000 chars</span>
                </div>
                <textarea
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  placeholder="The quick brown fox jumps over the lazy dog..."
                  className="w-full h-64 bg-slate-950 border border-white/5 rounded-[2rem] p-8 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all text-lg leading-relaxed resize-none shadow-inner"
                />
              </div>

              <div className="flex flex-col sm:flex-row gap-6 pt-4">
                <button
                  onClick={handleSynthesize}
                  disabled={isLoading || !text.trim()}
                  className="flex-grow py-6 rounded-2xl bg-indigo-600 text-white font-black text-xl glow-primary hover:bg-indigo-700 flex items-center justify-center gap-4 transition-all disabled:opacity-50 group"
                >
                  {isLoading ? (
                    <Loader2 className="h-7 w-7 animate-spin" />
                  ) : isPlaying ? (
                    <Music className="h-7 w-7 animate-bounce" />
                  ) : (
                    <Mic className="h-7 w-7 group-hover:scale-110 transition-transform" />
                  )}
                  {isLoading ? 'Synthesizing...' : isPlaying ? 'Voice Playing' : 'Synthesize Now'}
                </button>
                
                {audioUrl && (
                  <a 
                    href={audioUrl} 
                    download="aai-voice-generation.pcm"
                    className="px-8 py-6 rounded-2xl bg-white/5 border border-white/10 text-white font-bold hover:bg-white/10 transition-all flex items-center justify-center gap-2"
                  >
                    <Download className="h-5 w-5" /> Download
                  </a>
                )}
              </div>
            </div>
          </div>

          <div className="lg:col-span-4 space-y-6">
            <div className="bg-slate-900/40 border border-white/10 rounded-[2.5rem] p-8">
              <h3 className="text-sm font-black text-slate-300 uppercase tracking-widest mb-6 flex items-center gap-2">
                <Sparkles className="h-4 w-4 text-indigo-500" />
                Select Voice Model
              </h3>
              <div className="space-y-3">
                {voices.map((v) => (
                  <button
                    key={v.id}
                    onClick={() => setSelectedVoice(v.id)}
                    className={`w-full flex items-center justify-between p-4 rounded-2xl border transition-all duration-300 ${
                      selectedVoice === v.id 
                        ? 'bg-indigo-600 border-indigo-400 text-white shadow-xl shadow-indigo-500/20 translate-x-1' 
                        : 'bg-slate-950/50 border-white/5 text-slate-400 hover:border-white/20'
                    }`}
                  >
                    <div className="flex items-center gap-4">
                      <div className={`w-12 h-12 rounded-full flex items-center justify-center ${selectedVoice === v.id ? 'bg-white/20' : 'bg-slate-800'}`}>
                        {selectedVoice === v.id && isPlaying ? <Volume2 className="h-6 w-6 animate-pulse" /> : <Volume2 className="h-6 w-6" />}
                      </div>
                      <div className="text-left">
                        <p className="font-black text-sm">{v.name}</p>
                        <p className="text-[10px] font-bold opacity-50 uppercase tracking-tighter">{v.gender} • {v.style}</p>
                      </div>
                    </div>
                    {selectedVoice === v.id && <Play className="h-5 w-5 fill-current" />}
                  </button>
                ))}
              </div>
            </div>

            <AdSlot id="voice-lab-sidebar" format="sidebar" />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-20">
          {[
            { icon: Sparkles, title: 'Neural Clarity', desc: 'Industry-leading clarity and emotion mapping.' },
            { icon: Music, title: 'Zero Artifacts', desc: 'No robotic buzzing or digital distortion.' },
            /* Fixed: Added Zap icon to the features list */
            { icon: Zap, title: 'Real-time', desc: 'Optimized for high-speed, low-latency audio.' }
          ].map((item, i) => (
            <div key={i} className="p-8 rounded-3xl bg-slate-900/40 border border-white/5 text-center group hover:border-indigo-500/20 transition-all">
              <div className="w-12 h-12 bg-indigo-500/10 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:bg-indigo-500/20 transition-all">
                <item.icon className="h-6 w-6 text-indigo-500" />
              </div>
              <h3 className="text-lg font-bold mb-2">{item.title}</h3>
              <p className="text-slate-500 text-sm leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default VoicePage;
