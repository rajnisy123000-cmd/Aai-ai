
import React from 'react';
import { Check, Zap, Shield, Globe, Star } from 'lucide-react';
import { Link } from 'react-router-dom';
import AdSlot from '../components/AdSlot';

const tiers = [
  {
    name: 'Starter',
    price: '0',
    description: 'Perfect for exploring the power of AI.',
    features: ['Access to Gemini 3 Flash', '10 Image generations / day', 'Basic Voice synthesis', 'Standard support'],
    cta: 'Get Started',
    popular: false
  },
  {
    name: 'Pro',
    price: '29',
    description: 'The ultimate tool for creators and pros.',
    features: ['Unlimited Gemini 3 Pro Chat', 'Unlimited 4K Image generations', 'Advanced Voice Lab features', 'Priority API access', 'Early access to new models'],
    cta: 'Upgrade to Pro',
    popular: true
  },
  {
    name: 'Enterprise',
    price: 'Custom',
    description: 'Scale your business with dedicated AI.',
    features: ['Custom model fine-tuning', 'Dedicated account manager', 'SLA guarantees', 'Advanced security & SSO', 'Unlimited team seats'],
    cta: 'Contact Sales',
    popular: false
  }
];

const PricingPage: React.FC = () => {
  return (
    <div className="min-h-screen pt-32 pb-20 bg-slate-950 px-4">
      <div className="max-w-7xl mx-auto text-center mb-20">
        <h1 className="text-4xl md:text-6xl font-black mb-6">Simple, Transparent <span className="gradient-text">Pricing</span></h1>
        <p className="text-slate-400 text-xl max-w-2xl mx-auto">Choose the plan that fits your ambition. No hidden fees, just raw intelligence.</p>
      </div>

      <div className="max-w-7xl mx-auto grid md:grid-cols-3 gap-8 mb-20">
        {tiers.map((tier) => (
          <div 
            key={tier.name}
            className={`relative p-8 rounded-[2.5rem] border transition-all hover-lift flex flex-col ${
              tier.popular 
                ? 'bg-slate-900 border-indigo-500 shadow-2xl shadow-indigo-500/10' 
                : 'bg-slate-900/50 border-white/5 shadow-xl'
            }`}
          >
            {tier.popular && (
              <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full bg-indigo-500 text-white text-xs font-bold uppercase tracking-widest flex items-center gap-1">
                <Star className="h-3 w-3 fill-current" /> Most Popular
              </div>
            )}
            
            <div className="mb-8">
              <h3 className="text-2xl font-bold mb-2">{tier.name}</h3>
              <div className="flex items-baseline gap-1 mb-4">
                <span className="text-4xl font-black">${tier.price}</span>
                {tier.price !== 'Custom' && <span className="text-slate-500 font-medium">/mo</span>}
              </div>
              <p className="text-slate-400 text-sm leading-relaxed">{tier.description}</p>
            </div>

            <div className="space-y-4 mb-10 flex-grow">
              {tier.features.map((feature) => (
                <div key={feature} className="flex items-start gap-3 text-sm">
                  <Check className="h-5 w-5 text-indigo-500 shrink-0" />
                  <span className="text-slate-300">{feature}</span>
                </div>
              ))}
            </div>

            <Link
              to="/chat"
              className={`w-full py-4 rounded-2xl font-bold text-center transition-all ${
                tier.popular 
                  ? 'bg-indigo-600 text-white glow-primary hover:bg-indigo-700' 
                  : 'bg-white/5 text-white hover:bg-white/10 border border-white/10'
              }`}
            >
              {tier.cta}
            </Link>
          </div>
        ))}
      </div>

      {/* Partner Offer / Lead generation Slot */}
      <div className="max-w-5xl mx-auto mb-32">
         <AdSlot id="pricing-footer-leaderboard" format="horizontal" />
      </div>

      <div className="max-w-4xl mx-auto mt-32 grid grid-cols-2 md:grid-cols-4 gap-8 opacity-50">
        {[
          { icon: Zap, text: 'Instant Setup' },
          { icon: Shield, text: 'Safe & Secure' },
          { icon: Globe, text: 'Global Infra' },
          { icon: Star, text: 'Top Rated' }
        ].map((item) => (
          <div key={item.text} className="flex flex-col items-center gap-2">
            <item.icon className="h-6 w-6" />
            <span className="text-sm font-semibold">{item.text}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default PricingPage;
