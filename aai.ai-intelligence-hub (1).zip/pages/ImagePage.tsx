
import React, { useState, useEffect } from 'react';
import { Image as ImageIcon, Sparkles, Loader2, Download, Database, ShieldCheck, Zap, Layers, Info } from 'lucide-react';
import { generateImage } from '../services/geminiService';
import { supabase } from '../services/supabase';
import { GeneratedImage } from '../types';

const ImagePage: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [images, setImages] = useState<GeneratedImage[]>([]);
  const [isPro, setIsPro] = useState(false);
  const [aspectRatio, setAspectRatio] = useState<any>("1:1");
  const [imageSize, setImageSize] = useState<any>("1K");

  useEffect(() => {
    const fetchImages = async () => {
      const { data } = await supabase.from('generated_images').select('*').order('timestamp', { ascending: false });
      if (data) setImages(data);
    };
    fetchImages();
  }, []);

  const handleProToggle = async (value: boolean) => {
    if (value) {
      // Mandatory API key check for Gemini 3 Pro Image
      if (typeof window !== 'undefined' && (window as any).aistudio) {
        const hasKey = await (window as any).aistudio.hasSelectedApiKey();
        if (!hasKey) {
          await (window as any).aistudio.openSelectKey();
          // Proceeding as per instructions that key selection is assumed successful
        }
      }
    }
    setIsPro(value);
  };

  const handleGenerate = async () => {
    if (!prompt.trim() || isLoading) return;

    setIsLoading(true);
    try {
      const imageUrl = await generateImage(prompt, aspectRatio, isPro, imageSize);
      const newImage: GeneratedImage = {
        id: crypto.randomUUID(),
        url: imageUrl,
        prompt: prompt,
        timestamp: Date.now(),
      };
      
      setImages(prev => [newImage, ...prev]);
      
      await supabase.from('generated_images').insert([{
        id: newImage.id,
        url: newImage.url,
        prompt: newImage.prompt,
        timestamp: newImage.timestamp
      }]);

    } catch (error: any) {
      console.error(error);
      if (error.message?.includes("Requested entity was not found")) {
        // Reset key selection if entity not found error occurs
        if (typeof window !== 'undefined' && (window as any).aistudio) {
          await (window as any).aistudio.openSelectKey();
        }
      } else {
        alert(`Generation failed: ${error.message}`);
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen pt-24 bg-slate-950 px-4 pb-20">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col lg:flex-row gap-12">
          <div className="w-full lg:w-96 space-y-6">
            <div className="flex items-center justify-between">
              <h1 className="text-3xl font-black flex items-center gap-3 text-white">
                <ImageIcon className="text-indigo-500" /> Studio
              </h1>
              <div className="flex items-center gap-2 px-3 py-1 bg-slate-900 border border-white/5 rounded-full">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                <span className="text-[10px] font-bold text-slate-500 uppercase">System Live</span>
              </div>
            </div>

            <div className="p-1 bg-slate-900 border border-white/10 rounded-2xl flex relative overflow-hidden">
              <button 
                onClick={() => handleProToggle(false)}
                className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all relative z-10 ${!isPro ? 'bg-slate-800 text-white shadow-lg' : 'text-slate-500 hover:text-slate-300'}`}
              >
                Flash
              </button>
              <button 
                onClick={() => handleProToggle(true)}
                className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-2 relative z-10 ${isPro ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20' : 'text-slate-500 hover:text-slate-300'}`}
              >
                <Zap className="h-3 w-3" /> Pro Mode
              </button>
            </div>

            <div className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Image Prompt</label>
                  <span className="text-[10px] text-slate-600 font-medium italic">Supports descriptive text</span>
                </div>
                <textarea
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  placeholder="A hyper-realistic cyberpunk city in the rain, 8k, cinematic lighting..."
                  className="w-full h-32 bg-slate-950 border border-white/10 rounded-2xl p-4 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50 resize-none transition-all placeholder:text-slate-700"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Aspect Ratio</label>
                  <select 
                    value={aspectRatio} 
                    onChange={(e) => setAspectRatio(e.target.value)}
                    className="w-full bg-slate-900 border border-white/10 rounded-xl p-2.5 text-xs text-white outline-none focus:ring-1 focus:ring-indigo-500 cursor-pointer"
                  >
                    <option value="1:1">1:1 Square</option>
                    <option value="16:9">16:9 Wide</option>
                    <option value="9:16">9:16 Tall</option>
                    <option value="4:3">4:3 Classic</option>
                    <option value="3:4">3:4 Portrait</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Quality</label>
                  <select 
                    disabled={!isPro}
                    value={imageSize} 
                    onChange={(e) => setImageSize(e.target.value)}
                    className="w-full bg-slate-900 border border-white/10 rounded-xl p-2.5 text-xs text-white outline-none focus:ring-1 focus:ring-indigo-500 disabled:opacity-30 cursor-pointer"
                  >
                    <option value="1K">1K Standard</option>
                    <option value="2K">2K Ultra</option>
                    <option value="4K">4K Master</option>
                  </select>
                </div>
              </div>
            </div>

            <button
              onClick={handleGenerate}
              disabled={isLoading || !prompt.trim()}
              className="w-full py-5 rounded-2xl bg-indigo-600 text-white font-bold text-lg glow-primary hover:bg-indigo-700 flex items-center justify-center gap-3 transition-all disabled:opacity-50 disabled:cursor-not-allowed group active:scale-[0.98]"
            >
              {isLoading ? (
                <Loader2 className="animate-spin h-6 w-6" />
              ) : (
                <Sparkles className="h-6 w-6 group-hover:rotate-12 transition-transform" />
              )} 
              {isLoading ? 'Dreaming...' : 'Generate Assets'}
            </button>

            {isPro && (
              <div className="p-4 rounded-xl bg-indigo-500/5 border border-indigo-500/20 text-[10px] text-indigo-400 leading-relaxed flex gap-3">
                <ShieldCheck className="h-4 w-4 shrink-0" />
                <span>Pro mode utilizes <strong>Gemini 3 Pro</strong>. Ensure you have selected an API key from a <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" className="underline font-bold">paid GCP project</a>.</span>
              </div>
            )}
          </div>

          <div className="flex-1">
            <div className="flex items-center justify-between mb-8 border-b border-white/5 pb-4">
              <h2 className="text-xl font-bold flex items-center gap-2">
                <Layers className="h-5 w-5 text-indigo-500" />
                Asset Portfolio
              </h2>
              <div className="flex gap-4">
                <span className="text-slate-500 text-sm font-medium">{images.length} items</span>
                <button className="text-[10px] text-slate-600 font-bold uppercase tracking-wider hover:text-slate-300 transition-colors">Clear All</button>
              </div>
            </div>

            {images.length === 0 && !isLoading && (
              <div className="h-[500px] border-2 border-dashed border-white/5 rounded-[3rem] flex flex-col items-center justify-center text-slate-600 bg-slate-900/10">
                <div className="w-20 h-20 bg-slate-900 rounded-full flex items-center justify-center mb-6">
                  <ImageIcon className="h-8 w-8 opacity-20" />
                </div>
                <p className="font-medium text-lg">Your canvas is empty</p>
                <p className="text-sm opacity-50 mt-2">Describe an image and hit generate to begin.</p>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
              {isLoading && (
                <div className="aspect-square rounded-[2rem] bg-slate-900 border border-white/5 animate-pulse flex flex-col items-center justify-center gap-4">
                   <div className="w-12 h-12 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin" />
                   <p className="text-xs text-slate-500 font-bold uppercase tracking-widest">Rendering...</p>
                </div>
              )}
              {images.map((img) => (
                <div key={img.id} className="group relative aspect-square rounded-[2rem] overflow-hidden border border-white/10 bg-slate-900 hover-lift shadow-2xl">
                  <img src={img.url} className="w-full h-full object-cover" loading="lazy" alt={img.prompt} />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/95 via-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-all duration-300 p-8 flex flex-col justify-end translate-y-4 group-hover:translate-y-0">
                    <p className="text-white text-sm font-medium mb-6 line-clamp-3 leading-relaxed">{img.prompt}</p>
                    <div className="flex gap-3">
                      <a 
                        href={img.url} 
                        download={`aai-${img.id}.png`}
                        className="flex-1 flex items-center justify-center gap-2 bg-white text-black py-3 rounded-xl font-bold text-xs hover:bg-slate-200 transition-colors active:scale-95"
                      >
                        <Download className="h-4 w-4" /> Save Asset
                      </a>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ImagePage;
