
export interface Source {
  uri: string;
  title: string;
}

export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
  sources?: Source[];
}

export interface ChatSession {
  id: string;
  title: string;
  messages: Message[];
  lastModified: number;
}

export interface GeneratedImage {
  id: string;
  url: string;
  prompt: string;
  timestamp: number;
}

export interface GeneratedVideo {
  id: string;
  url: string;
  prompt: string;
  timestamp: number;
}

export enum AppRoute {
  HOME = '/',
  CHAT = '/chat',
  IMAGE = '/image',
  VIDEO = '/video',
  FORGE = '/forge',
  VOICE = '/voice',
  PRICING = '/pricing'
}
